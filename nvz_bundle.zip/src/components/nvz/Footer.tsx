import { Mail, MessageCircle } from "lucide-react";
import { WHATSAPP_URL } from "./WhatsAppFloat";

export const Footer = () => (
  <footer className="border-t border-border bg-card/30">
    <div className="container py-14 grid md:grid-cols-4 gap-10">
      <div className="md:col-span-2">
        <a href="#top" className="flex items-center gap-2 font-display font-bold text-2xl">
          <span className="text-primary glow-text">Nv</span>
          <span>Z</span>
        </a>
        <p className="mt-4 text-sm text-muted-foreground max-w-sm leading-relaxed">
          NvZ — Consultoria e Desenvolvimento. Há mais de 3 anos ajudando
          empresas a organizarem, evoluírem e escalarem seus negócios através da
          tecnologia.
        </p>
      </div>

      <div>
        <h4 className="font-display font-semibold text-sm mb-4">Navegação</h4>
        <ul className="space-y-2.5 text-sm text-muted-foreground">
          <li><a href="#servicos" className="hover:text-primary transition-smooth">Serviços</a></li>
          <li><a href="#metodo" className="hover:text-primary transition-smooth">Método</a></li>
          <li><a href="#portfolio" className="hover:text-primary transition-smooth">Projetos</a></li>
          <li><a href="#depoimentos" className="hover:text-primary transition-smooth">Depoimentos</a></li>
          <li><a href="#contato" className="hover:text-primary transition-smooth">Contato</a></li>
        </ul>
      </div>

      <div>
        <h4 className="font-display font-semibold text-sm mb-4">Contato</h4>
        <ul className="space-y-2.5 text-sm text-muted-foreground">
          <li>
            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 hover:text-primary transition-smooth"
            >
              <MessageCircle className="w-4 h-4" /> (16) 99787-1568
            </a>
          </li>
          <li>
            <a
              href="mailto:nvztinfo@gmail.com"
              className="inline-flex items-center gap-2 hover:text-primary transition-smooth"
            >
              <Mail className="w-4 h-4" /> nvztinfo@gmail.com
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div className="border-t border-border/60">
      <div className="container py-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-muted-foreground">
        <p>© {new Date().getFullYear()} NvZ — Consultoria e Desenvolvimento. Todos os direitos reservados.</p>
        <p className="font-mono">CNPJ - 62.257.096/0001-25 · Araraquara/SP</p>
      </div>
    </div>
  </footer>
);
