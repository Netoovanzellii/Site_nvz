import { useState } from "react";
import { ArrowRight, MessageCircle, Mail, Loader2, CheckCircle2 } from "lucide-react";
import { WHATSAPP_URL } from "./WhatsAppFloat";
import { Reveal } from "./Reveal";

export const FinalCta = () => {
  const [status, setStatus] = useState<"idle" | "sending" | "sent">("idle");
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setStatus("sending");
    // Simulated submission — user can wire a real backend later
    setTimeout(() => setStatus("sent"), 900);
  };

  return (
    <section id="contato" className="relative py-24 lg:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-grid opacity-50" aria-hidden />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] rounded-full bg-primary/10 blur-[140px]" aria-hidden />

      <div className="container relative grid lg:grid-cols-2 gap-12 items-center">
        <Reveal direction="right">
          <h2 className="font-display text-4xl lg:text-6xl font-bold tracking-tight leading-[1.05]">
            Pronto para levar sua empresa para o{" "}
            <span className="text-gradient glow-text">próximo nível?</span>
          </h2>
          <p className="mt-6 text-lg text-muted-foreground max-w-lg">
            Conte seu desafio. Em até 1 dia útil retornamos com uma proposta
            inicial sem compromisso.
          </p>

          <div className="mt-8 space-y-3">
            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center gap-3 rounded-xl border border-border bg-card/60 p-4 hover:border-primary/50 transition-smooth"
            >
              <div className="w-10 h-10 rounded-lg bg-primary/10 border border-primary/30 flex items-center justify-center">
                <MessageCircle className="w-5 h-5 text-primary" />
              </div>
              <div>
                <div className="text-xs text-muted-foreground">WhatsApp</div>
                <div className="font-semibold">(16) 99787-1568</div>
              </div>
              <ArrowRight className="ml-auto w-4 h-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-smooth" />
            </a>
            <a
              href="mailto:nvztinfo@gmail.com"
              className="group flex items-center gap-3 rounded-xl border border-border bg-card/60 p-4 hover:border-primary/50 transition-smooth"
            >
              <div className="w-10 h-10 rounded-lg bg-primary/10 border border-primary/30 flex items-center justify-center">
                <Mail className="w-5 h-5 text-primary" />
              </div>
              <div>
                <div className="text-xs text-muted-foreground">E-mail</div>
                <div className="font-semibold">nvztinfo@gmail.com</div>
              </div>
              <ArrowRight className="ml-auto w-4 h-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-smooth" />
            </a>
          </div>
        </Reveal>

        <Reveal direction="left" delay={150}>
          <form
            onSubmit={submit}
            className="card-glass rounded-3xl p-8 lg:p-10 space-y-5"
          >
          {status === "sent" ? (
            <div className="text-center py-10">
              <CheckCircle2 className="w-14 h-14 text-primary mx-auto mb-4" />
              <h3 className="font-display text-2xl font-bold">
                Mensagem enviada!
              </h3>
              <p className="mt-2 text-muted-foreground">
                Obrigado pelo contato. Em breve retornamos.
              </p>
            </div>
          ) : (
            <>
              <div>
                <label className="text-xs font-mono text-muted-foreground uppercase tracking-wider">
                  Nome
                </label>
                <input
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="mt-2 w-full rounded-xl border border-border bg-background/50 px-4 py-3 text-foreground outline-none focus:border-primary transition-smooth"
                  placeholder="Seu nome"
                />
              </div>
              <div>
                <label className="text-xs font-mono text-muted-foreground uppercase tracking-wider">
                  E-mail
                </label>
                <input
                  required
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="mt-2 w-full rounded-xl border border-border bg-background/50 px-4 py-3 text-foreground outline-none focus:border-primary transition-smooth"
                  placeholder="voce@empresa.com"
                />
              </div>
              <div>
                <label className="text-xs font-mono text-muted-foreground uppercase tracking-wider">
                  Como podemos ajudar?
                </label>
                <textarea
                  required
                  rows={4}
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  className="mt-2 w-full rounded-xl border border-border bg-background/50 px-4 py-3 text-foreground outline-none focus:border-primary transition-smooth resize-none"
                  placeholder="Conte brevemente seu desafio..."
                />
              </div>
              <button
                type="submit"
                disabled={status === "sending"}
                className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-6 py-4 font-semibold text-primary-foreground shadow-glow transition-smooth hover:shadow-glow-strong disabled:opacity-60"
              >
                {status === "sending" ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Enviando...
                  </>
                ) : (
                  <>
                    Solicitar orçamento
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
              <p className="text-xs text-center text-muted-foreground">
                Retorno em até 1 dia útil.
              </p>
            </>
          )}
          </form>
        </Reveal>
      </div>
    </section>
  );
};
