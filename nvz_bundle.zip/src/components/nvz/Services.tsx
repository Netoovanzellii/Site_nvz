import { BrainCircuit, Code2, Headset, Check, ArrowRight } from "lucide-react";
import { WHATSAPP_URL } from "./WhatsAppFloat";
import { Reveal } from "./Reveal";

const services = [
  {
    icon: BrainCircuit,
    title: "Consultoria em TI",
    tagline: "Clareza estratégica para decisões melhores.",
    desc: "Diagnosticamos sua estrutura tecnológica, identificamos riscos e oportunidades e traduzimos isso em um plano concreto de evolução.",
    points: [
      "Diagnóstico técnico completo",
      "Mapeamento de processos",
      "Redução de custos operacionais",
      "Apoio à tomada de decisão",
    ],
  },
  {
    icon: Code2,
    title: "Desenvolvimento Web & Sistemas",
    tagline: "Software que gera resultado, não só entrega.",
    desc: "Criamos sites, sistemas e automações modernos, escaláveis e seguros sob medida para o seu modelo de negócio.",
    points: [
      "Sites institucionais premium",
      "Sistemas web sob medida",
      "Automação de processos",
      "Integração com APIs e ERPs",
    ],
    highlight: true,
  },
  {
    icon: Headset,
    title: "Suporte & Sustentação",
    tagline: "Operação estável. Sem retrabalho. Sem sustos.",
    desc: "Mantemos sua operação rodando preventivamente. Menos paradas, mais eficiência e segurança no dia a dia.",
    points: [
      "Suporte técnico contínuo",
      "Manutenção preventiva",
      "Gestão de usuários",
      "Otimização de desempenho",
    ],
  },
];

export const Services = () => (
  <section id="servicos" className="relative py-24 lg:py-32">
    <div className="container">
      <Reveal className="max-w-2xl mb-16">
        <h2 className="font-display text-4xl lg:text-5xl font-bold tracking-tight">
          O que a NvZ{" "}
          <span className="text-gradient">entrega</span> na prática.
        </h2>
        <p className="mt-4 text-muted-foreground text-lg">
          Três frentes que se complementam para levar sua empresa ao próximo
          nível da estratégia à operação contínua.
        </p>
      </Reveal>

      <div className="grid lg:grid-cols-3 gap-6">
        {services.map((s, i) => (
          <Reveal key={s.title} delay={i * 100}>
          <article
            className={`card-glass rounded-2xl p-8 flex flex-col h-full ${
              s.highlight ? "lg:-translate-y-4 border-primary/40 shadow-card" : ""
            }`}
          >
            <div className="flex items-center justify-between mb-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-primary flex items-center justify-center shadow-glow">
                <s.icon className="w-6 h-6 text-primary-foreground" strokeWidth={2} />
              </div>
              {s.highlight && (
                <span className="text-[10px] font-mono uppercase tracking-widest text-primary border border-primary/40 rounded-full px-2 py-1">
                  Mais procurado
                </span>
              )}
            </div>

            <h3 className="font-display text-2xl font-bold">{s.title}</h3>
            <p className="mt-2 text-sm font-mono text-primary">{s.tagline}</p>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              {s.desc}
            </p>

            <ul className="mt-6 space-y-2.5">
              {s.points.map((p) => (
                <li key={p} className="flex items-start gap-2.5 text-sm">
                  <Check className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                  <span>{p}</span>
                </li>
              ))}
            </ul>

            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-8 inline-flex items-center gap-2 text-sm font-semibold text-primary group"
            >
              Quero saber mais
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </a>
          </article>
          </Reveal>
        ))}
      </div>
    </div>
  </section>
);
