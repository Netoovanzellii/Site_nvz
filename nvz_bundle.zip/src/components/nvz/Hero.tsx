import { ArrowRight, MessageCircle, Cpu, Code2, Terminal } from "lucide-react";
import { WHATSAPP_URL } from "./WhatsAppFloat";

export const Hero = () => {
  return (
    <section
      id="top"
      className="relative min-h-screen flex items-center overflow-hidden pt-24 pb-16"
    >
      {/* Backgrounds */}
      <div className="absolute inset-0 bg-gradient-hero" aria-hidden />
      <div className="absolute inset-0 bg-grid" aria-hidden />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full bg-primary/10 blur-[140px]" aria-hidden />

      <div className="container relative grid lg:grid-cols-2 gap-12 items-center">
        {/* Text */}
        <div className="animate-fade-up">
          <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/5 px-4 py-1.5 text-xs font-mono text-primary mb-6">
            <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse-glow" />
            Consultoria &amp; Desenvolvimento · +3 anos no mercado
          </div>

          <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold leading-[1.05] tracking-tight">
            Tecnologia que{" "}
            <span className="text-gradient glow-text">impulsiona</span>
            <br />
            o seu negócio.
          </h1>

          <p className="mt-6 text-lg text-muted-foreground max-w-xl leading-relaxed">
            Consultoria em TI, desenvolvimento web e suporte sob medida.
            Transformamos processos em soluções digitais, modernas, seguras e
            escaláveis.
          </p>

          <div className="mt-10 flex flex-col sm:flex-row gap-4">
            <a
              href="#contato"
              className="group inline-flex items-center justify-center gap-2 rounded-full bg-primary px-7 py-4 font-semibold text-primary-foreground shadow-glow transition-smooth hover:shadow-glow-strong hover:scale-[1.02]"
            >
              Solicitar orçamento
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </a>
            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 rounded-full border border-border bg-card/50 px-7 py-4 font-semibold text-foreground hover:border-primary/50 hover:text-primary transition-smooth"
            >
              <MessageCircle className="h-4 w-4" />
              Falar no WhatsApp
            </a>
          </div>

          <div className="mt-12 grid grid-cols-3 gap-6 max-w-md">
            {[
              { k: "+3", v: "anos de atuação" },
              { k: "100%", v: "sob medida" },
              { k: "24/7", v: "suporte contínuo" },
            ].map((s) => (
              <div key={s.v}>
                <div className="font-display text-2xl font-bold text-primary">
                  {s.k}
                </div>
                <div className="text-xs text-muted-foreground mt-1">{s.v}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Visual */}
        <div className="relative hidden lg:block animate-fade-up" style={{ animationDelay: "0.2s" }}>
          <HeroVisual />
        </div>
      </div>
    </section>
  );
};

const HeroVisual = () => (
  <div className="relative aspect-square max-w-lg mx-auto">
    {/* Glow ring */}
    <div className="absolute inset-10 rounded-full border border-primary/30 animate-pulse-glow" />
    <div className="absolute inset-20 rounded-full border border-primary/20" />
    <div className="absolute inset-0 rounded-full bg-primary/10 blur-3xl" />

    {/* Central chip */}
    <div className="absolute inset-0 flex items-center justify-center">
      <div className="relative w-40 h-40 rounded-2xl bg-gradient-card border border-primary/40 shadow-glow-strong flex items-center justify-center animate-float">
        <Cpu className="w-16 h-16 text-primary" strokeWidth={1.2} />
        <div className="absolute inset-0 rounded-2xl border border-primary/20 animate-pulse-glow" />
        {/* Connector lines */}
        {[0, 90, 180, 270].map((deg) => (
          <span
            key={deg}
            className="absolute top-1/2 left-1/2 h-px w-32 bg-gradient-to-r from-primary to-transparent origin-left"
            style={{ transform: `rotate(${deg}deg)` }}
          />
        ))}
      </div>
    </div>

    {/* Floating code card */}
    <div
      className="absolute top-6 -left-4 w-56 rounded-xl border border-border bg-card/90 backdrop-blur p-4 shadow-card animate-float"
      style={{ animationDelay: "1s" }}
    >
      <div className="flex items-center gap-1.5 mb-3">
        <span className="w-2 h-2 rounded-full bg-destructive/70" />
        <span className="w-2 h-2 rounded-full bg-primary/50" />
        <span className="w-2 h-2 rounded-full bg-primary" />
        <span className="ml-auto text-[10px] font-mono text-muted-foreground">
          deploy.ts
        </span>
      </div>
      <div className="font-mono text-[11px] leading-relaxed space-y-1">
        <div><span className="text-primary">const</span> <span className="text-foreground">nvz</span> = {"{"}</div>
        <div className="pl-3 text-muted-foreground">stack: <span className="text-primary">"scalable"</span>,</div>
        <div className="pl-3 text-muted-foreground">impact: <span className="text-primary">"real"</span></div>
        <div>{"}"}</div>
      </div>
    </div>

    {/* Floating metric card */}
    <div
      className="absolute bottom-4 -right-2 w-52 rounded-xl border border-border bg-card/90 backdrop-blur p-4 shadow-card animate-float"
      style={{ animationDelay: "2s" }}
    >
      <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
        <Terminal className="w-3.5 h-3.5 text-primary" />
        uptime · últimos 30d
      </div>
      <div className="font-display text-2xl font-bold text-primary">99.98%</div>
      <div className="mt-3 flex items-end gap-1 h-10">
        {[40, 60, 45, 70, 55, 80, 65, 90, 75, 95].map((h, i) => (
          <span
            key={i}
            className="flex-1 rounded-sm bg-gradient-to-t from-primary/20 to-primary"
            style={{ height: `${h}%` }}
          />
        ))}
      </div>
    </div>

    {/* Floating code icon */}
    <div
      className="absolute top-1/2 -right-6 w-12 h-12 rounded-xl border border-primary/40 bg-card flex items-center justify-center animate-float"
      style={{ animationDelay: "0.5s" }}
    >
      <Code2 className="w-5 h-5 text-primary" />
    </div>
  </div>
);
