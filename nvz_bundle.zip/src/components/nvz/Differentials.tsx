import { Handshake, Layers, Sparkles, ShieldCheck } from "lucide-react";
import { Reveal } from "./Reveal";

const items = [
  {
    icon: Handshake,
    title: "Atendimento personalizado",
    desc: "Cada cliente é único. Ouvimos, diagnosticamos e propomos com base no seu contexto real.",
  },
  {
    icon: Layers,
    title: "Soluções sob medida",
    desc: "Nada de pacotes engessados. Tecnologia desenhada para o seu processo e seus objetivos.",
  },
  {
    icon: Sparkles,
    title: "Consultoria + Execução",
    desc: "Unimos visão estratégica e mão na massa. Da ideia ao deploy, com clareza em cada etapa.",
  },
  {
    icon: ShieldCheck,
    title: "Parceria de longo prazo",
    desc: "Acompanhamos seu crescimento com suporte contínuo, evolução e segurança operacional.",
  },
];

export const Differentials = () => (
  <section className="relative py-20 border-y border-border/60">
    <div className="container">
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {items.map((it, i) => (
          <Reveal key={it.title} delay={i * 80}>
            <div className="card-glass rounded-2xl p-6 h-full">
              <div className="w-11 h-11 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center mb-4">
                <it.icon className="w-5 h-5 text-primary" />
              </div>
              <h3 className="font-display font-semibold text-lg mb-2">
                {it.title}
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {it.desc}
              </p>
            </div>
          </Reveal>
        ))}
      </div>
    </div>
  </section>
);
