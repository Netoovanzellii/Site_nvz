import { ArrowUpRight } from "lucide-react";
import { Reveal } from "./Reveal";

const projects = [
  {
    tag: "Automação · Integração com ERP",
    title: "Automação de processo relacionado à precificação",
    problem:
      "Cliente perdia horas consolidando planilhas e atualizando preços item a item conforme alteração de matéria-prima",
    solution:
      "Desenvolvemos um sistema integrado com seu ERP, automatizando o processo de precificação reduzindo o tempo operacional em 85%.",
    stats: [
      { k: "-68%", v: "tempo operacional" },
      { k: "+3x", v: "capacidade de análise" },
    ],
  },
  {
    tag: "Consultoria + Automação · Indústria",
    title: "Reestruturação da TI e integração com ERP",
    problem:
      "Processos manuais causavam retrabalho e falhas de estoque, impactando faturamento e prazos.",
    solution:
      "Diagnóstico completo, integração via APIs com o ERP e automação de rotinas críticas, estabilizando a operação.",
    stats: [
      { k: "-42%", v: "erros operacionais" },
      { k: "24/7", v: "operação monitorada" },
    ],
  },
];

export const Portfolio = () => (
  <section id="portfolio" className="relative py-24 lg:py-32">
    <div className="container">
      <Reveal className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-16">
        <div className="max-w-2xl">
          <h2 className="font-display text-4xl lg:text-5xl font-bold tracking-tight">
            Problema, solução e{" "}
            <span className="text-gradient">resultado.</span>
          </h2>
        </div>
        <p className="text-muted-foreground max-w-sm">
          Cases reais de como a NvZ traduz desafios de negócio em tecnologia que
          gera impacto mensurável.
        </p>
      </Reveal>

      <div className="grid lg:grid-cols-2 gap-6">
        {projects.map((p, i) => (
          <Reveal key={p.title} delay={i * 120} direction={i % 2 === 0 ? "right" : "left"}>
          <article
            className="card-glass rounded-3xl p-8 lg:p-10 relative overflow-hidden h-full"
          >
            <div className="absolute top-0 right-0 w-40 h-40 bg-primary/10 blur-3xl rounded-full" />
            <div className="relative">
              <div className="flex items-center justify-between mb-6">
                <span className="text-xs font-mono text-primary uppercase tracking-wider">
                  {p.tag}
                </span>
                <ArrowUpRight className="w-5 h-5 text-muted-foreground" />
              </div>
              <h3 className="font-display text-2xl lg:text-3xl font-bold leading-tight">
                {p.title}
              </h3>

              <div className="mt-6 space-y-4 text-sm leading-relaxed">
                <div>
                  <span className="font-mono text-xs uppercase text-muted-foreground tracking-wider">
                    Problema
                  </span>
                  <p className="mt-1 text-foreground/90">{p.problem}</p>
                </div>
                <div>
                  <span className="font-mono text-xs uppercase text-primary tracking-wider">
                    Solução
                  </span>
                  <p className="mt-1 text-foreground/90">{p.solution}</p>
                </div>
              </div>

              <div className="mt-8 pt-6 border-t border-border grid grid-cols-2 gap-6">
                {p.stats.map((s) => (
                  <div key={s.v}>
                    <div className="font-display text-3xl font-bold text-primary">
                      {s.k}
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">
                      {s.v}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </article>
          </Reveal>
        ))}
      </div>
    </div>
  </section>
);
