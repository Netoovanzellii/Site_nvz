import { Search, PenTool, Rocket, LineChart } from "lucide-react";
import { Reveal } from "./Reveal";

const steps = [
  {
    icon: Search,
    num: "01",
    title: "Entendimento",
    desc: "Mergulhamos no seu negócio, objetivos e dores reais antes de propor qualquer coisa.",
  },
  {
    icon: PenTool,
    num: "02",
    title: "Planejamento",
    desc: "Desenhamos a estratégia técnica e o escopo com transparência, prazos e métricas.",
  },
  {
    icon: Rocket,
    num: "03",
    title: "Execução",
    desc: "Implementamos com qualidade, entregas contínuas e comunicação próxima.",
  },
  {
    icon: LineChart,
    num: "04",
    title: "Evolução",
    desc: "Acompanhamos, otimizamos e escalamos a solução conforme o crescimento.",
  },
];

export const Process = () => (
  <section id="metodo" className="relative py-24 lg:py-32 border-y border-border/60">
    <div className="container">
      <Reveal className="max-w-2xl mb-16">
        <h2 className="font-display text-4xl lg:text-5xl font-bold tracking-tight">
          Como trabalhamos{" "}
          <span className="text-gradient">com você.</span>
        </h2>
        <p className="mt-4 text-muted-foreground text-lg">
          Um processo claro em quatro etapas para que você saiba exatamente
          onde estamos e para onde vamos.
        </p>
      </Reveal>

      <div className="relative grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="hidden lg:block absolute top-10 left-[12%] right-[12%] h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent" />
        {steps.map((s, i) => (
          <Reveal key={s.num} delay={i * 100}>
            <div className="relative card-glass rounded-2xl p-6 h-full">
              <div className="flex items-center justify-between mb-6">
                <div className="w-12 h-12 rounded-xl border border-primary/40 bg-card flex items-center justify-center">
                  <s.icon className="w-5 h-5 text-primary" />
                </div>
                <span className="font-mono text-sm text-primary/60">{s.num}</span>
              </div>
              <h3 className="font-display text-xl font-semibold">{s.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                {s.desc}
              </p>
            </div>
          </Reveal>
        ))}
      </div>
    </div>
  </section>
);
