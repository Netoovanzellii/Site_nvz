import { Nav } from "@/components/nvz/Nav";
import { Hero } from "@/components/nvz/Hero";
import { Differentials } from "@/components/nvz/Differentials";
import { Services } from "@/components/nvz/Services";
import { ImpactBanner } from "@/components/nvz/ImpactBanner";
import { Portfolio } from "@/components/nvz/Portfolio";
import { Process } from "@/components/nvz/Process";
import { FinalCta } from "@/components/nvz/FinalCta";
import { Footer } from "@/components/nvz/Footer";
import { WhatsAppFloat } from "@/components/nvz/WhatsAppFloat";

const Index = () => {
  return (
    <main className="min-h-screen bg-background text-foreground">
      <Nav />
      <Hero />
      <Differentials />
      <Services />
      <ImpactBanner />
      <Portfolio />
      <Process />
      <FinalCta />
      <Footer />
      <WhatsAppFloat />
    </main>
  );
};

export default Index;
